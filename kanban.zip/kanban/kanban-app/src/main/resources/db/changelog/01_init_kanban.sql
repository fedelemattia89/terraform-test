CREATE TABLE kanban (
    id SERIAL PRIMARY KEY,
    title TEXT
);